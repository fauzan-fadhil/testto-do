package com.example.todolisttest;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    Button login, register;
    EditText inputUsername, inputPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        inputUsername = findViewById(R.id.inputUsername);
        inputPassword = findViewById(R.id.inputPassword);

        login = findViewById(R.id.Login);
        register = findViewById(R.id.Register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                LoginActivity.this.finish();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (inputUsername.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this, "Isi Dulu username", Toast.LENGTH_SHORT).show();
                } else if (inputPassword.getText().toString().equals("")){
                    Toast.makeText(LoginActivity.this, "Isi Dulu Password", Toast.LENGTH_SHORT).show();
                } else {
                    Logindata();
                }
            }
        });
    }

    private void Logindata(){
        String url_json = "http://94.74.86.174:8080/api/login";
        final RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_json,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            Log.e("response", response);
                           if (jsonObject.getString("statusCode").equals("2110")){
                               Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                               startActivity(intent);
                           } else if (jsonObject.getString("statusCode").equals("401")) {
                               new AlertDialog.Builder(LoginActivity.this)
                                       .setTitle("Pemberitahuan")
                                       .setMessage("user Pass Salah")
                                       .setPositiveButton(android.R.string.ok, null)
                                       .show();
                           }

                        } catch(JSONException e) {
                            e.printStackTrace();
                        }
                        requestQueue.stop();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error instanceof TimeoutError) {
                    Toast.makeText(LoginActivity.this,
                            "Oops. request ke server gagal coba lagi",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError) {
                }
                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG);
                Log.e("pos trx Error", error.toString());
                requestQueue.stop();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                // Buat objek JSON untuk data login
                JSONObject jsonBody = new JSONObject();
                try {
                    jsonBody.put("username", inputUsername.getText().toString());
                    jsonBody.put("password", inputPassword.getText().toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return jsonBody.toString().getBytes(); // Konversi JSON ke byte array
            }
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }
}