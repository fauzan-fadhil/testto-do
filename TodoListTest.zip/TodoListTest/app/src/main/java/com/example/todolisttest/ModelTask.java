package com.example.todolisttest;

public class ModelTask {
    private String task_model;

    public ModelTask() {

    }

    public ModelTask(String taks) {
        this.task_model = taks;
    }

    public String getWall_title() {
        return task_model;
    }


}
