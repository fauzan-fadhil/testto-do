package com.example.todolisttest;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Random;

public class TaskAdapter extends RecyclerView.Adapter {
    static ArrayList<ModelTask> wallLists;
    public static ArrayList<ModelTask> mFilteredList;
    Intent intent;
    public Context context;


    public TaskAdapter(ArrayList<ModelTask> wallLists, Context context) {
        TaskAdapter.wallLists = wallLists;
        mFilteredList = wallLists;
        this.context = context;

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_task, parent, false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (holder instanceof ViewHolder) {
            final ModelTask webList = mFilteredList.get(position);
            ((ViewHolder) holder).tvtask.setText(webList.getWall_title());

        }
    }

    @Override
    public int getItemCount() {
        return mFilteredList == null ? 0 : mFilteredList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvtask;
        public ViewHolder(View itemView) {
            super(itemView);
            tvtask = itemView.findViewById(R.id.tvtask);

        }
    }
}