package com.example.todolisttest;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    EditText inputUsername, inputPassword, inputEmail;
    Button Register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        Register = findViewById(R.id.Register);
        inputUsername = findViewById(R.id.inputUsername);
        inputPassword = findViewById(R.id.inputPassword);
        inputEmail = findViewById(R.id.inputEmail);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (inputUsername.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this, "Isi Dulu username", Toast.LENGTH_SHORT).show();
                } else if (inputPassword.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this, "Isi Dulu Password", Toast.LENGTH_SHORT).show();
                } else if (inputEmail.getText().toString().equals("")){
                    Toast.makeText(RegisterActivity.this, "Isi Dulu Email", Toast.LENGTH_SHORT).show();
                } else {
                    Registerdata();
                }
            }
        });
    }

    private void Registerdata(){
        String url_json = "http://94.74.86.174:8080/api/register";
        final RequestQueue requestQueue = Volley.newRequestQueue(RegisterActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url_json,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            Log.e("response", response);
                            if (jsonObject.getString("statusCode").equals("2000")){
                                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                startActivity(intent);
                                RegisterActivity.this.finish();
                            } else if (jsonObject.getString("statusCode").equals("400")) {
                                new AlertDialog.Builder(RegisterActivity.this)
                                        .setTitle("Pemberitahuan")
                                        .setMessage("Register Gagal")
                                        .setPositiveButton(android.R.string.ok, null)
                                        .show();
                            }

                        } catch(JSONException e) {
                            e.printStackTrace();
                        }
                        requestQueue.stop();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (error instanceof TimeoutError) {
                    Toast.makeText(RegisterActivity.this,
                            "Oops. request ke server gagal coba lagi",
                            Toast.LENGTH_LONG).show();
                } else if (error instanceof NetworkError) {
                }
                Toast.makeText(RegisterActivity.this, error.toString(), Toast.LENGTH_LONG);
                Log.e("pos trx Error", error.toString());
                requestQueue.stop();
            }
        }) {
            @Override
            public byte[] getBody() throws AuthFailureError {
                // Buat objek JSON untuk data login
                JSONObject jsonBody = new JSONObject();
                try {
                    jsonBody.put("email", inputEmail.getText().toString());
                    jsonBody.put("username", inputUsername.getText().toString());
                    jsonBody.put("password", inputPassword.getText().toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return jsonBody.toString().getBytes(); // Konversi JSON ke byte array
            }
            @Override
            public Map<String, String> getHeaders() {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                return headers;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }
}